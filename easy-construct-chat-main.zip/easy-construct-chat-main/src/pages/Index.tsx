
import React, { useState } from 'react';
import { Send, Calculator, Home, MapPin, Building, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

interface ConstructionParams {
  area: number;
  location: string;
  constructionType: string;
  materialQuality: string;
}

const Index = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hi there! I'm Loveable, your friendly construction cost assistant! 🏗️ I'm here to help you estimate construction costs and find ways to save money. Let's start by getting some basic info about your project.",
      timestamp: new Date()
    }
  ]);

  const [showForm, setShowForm] = useState(true);
  const [constructionParams, setConstructionParams] = useState<ConstructionParams>({
    area: 0,
    location: '',
    constructionType: '',
    materialQuality: ''
  });

  // Simple cost calculation logic based on location and quality
  const calculateCosts = (params: ConstructionParams) => {
    // Base rates per square foot based on location (in USD)
    const locationRates: { [key: string]: number } = {
      'new-york': 200,
      'california': 180,
      'texas': 120,
      'florida': 130,
      'illinois': 140,
      'other': 110
    };

    // Quality multipliers
    const qualityMultipliers: { [key: string]: number } = {
      'standard': 1.0,
      'premium': 1.4
    };

    // Construction type multipliers
    const typeMultipliers: { [key: string]: number } = {
      'residential': 1.0,
      'commercial': 1.3
    };

    const baseRate = locationRates[params.location] || locationRates['other'];
    const qualityMultiplier = qualityMultipliers[params.materialQuality] || 1.0;
    const typeMultiplier = typeMultipliers[params.constructionType] || 1.0;

    const totalRate = baseRate * qualityMultiplier * typeMultiplier;
    const totalCost = params.area * totalRate;

    // Cost breakdown (approximate percentages)
    const materialCost = totalCost * 0.4;
    const laborCost = totalCost * 0.35;
    const overheadCost = totalCost * 0.25;

    return {
      totalCost,
      materialCost,
      laborCost,
      overheadCost,
      ratePerSqft: totalRate
    };
  };

  // Generate cost-saving suggestions based on parameters
  const getCostSavingSuggestions = (params: ConstructionParams) => {
    const suggestions = [];

    if (params.materialQuality === 'premium') {
      suggestions.push("💡 Consider using standard quality materials for non-visible areas - you could save 15-20%!");
    }

    if (params.location === 'new-york' || params.location === 'california') {
      suggestions.push("🚚 Use local materials to avoid high transport costs in your area");
      suggestions.push("🧱 Consider fly ash bricks instead of red bricks - they're cheaper and eco-friendly!");
    }

    suggestions.push("⏰ Plan construction during off-season (winter) for better labor rates");
    suggestions.push("🏗️ Buy materials in bulk to get wholesale prices");
    
    if (params.constructionType === 'residential') {
      suggestions.push("🏠 Consider prefab components for faster construction and cost savings");
    }

    return suggestions;
  };

  const handleFormSubmit = () => {
    if (!constructionParams.area || !constructionParams.location || 
        !constructionParams.constructionType || !constructionParams.materialQuality) {
      return;
    }

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: `I want to build a ${constructionParams.constructionType} project of ${constructionParams.area} sq ft in ${constructionParams.location} with ${constructionParams.materialQuality} quality materials.`,
      timestamp: new Date()
    };

    // Calculate costs
    const costs = calculateCosts(constructionParams);
    const suggestions = getCostSavingSuggestions(constructionParams);

    // Create bot response
    const botResponse: Message = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: `Great! I've calculated the costs for your ${constructionParams.area} sq ft ${constructionParams.constructionType} project. Here's what you're looking at:

💰 **Total Estimated Cost: $${costs.totalCost.toLocaleString()}**
📊 **Rate per sq ft: $${costs.ratePerSqft.toFixed(2)}**

**Cost Breakdown:**
🧱 Materials: $${costs.materialCost.toLocaleString()} (40%)
👷 Labor: $${costs.laborCost.toLocaleString()} (35%)
🏢 Overhead: $${costs.overheadCost.toLocaleString()} (25%)

**Money-Saving Tips:**
${suggestions.map(tip => `${tip}`).join('\n')}

Want to explore different options? Just fill out the form again with different parameters!`,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage, botResponse]);
    setShowForm(false);
  };

  const resetChat = () => {
    setShowForm(true);
    setConstructionParams({
      area: 0,
      location: '',
      constructionType: '',
      materialQuality: ''
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
              <Calculator className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">Loveable</h1>
              <p className="text-sm text-gray-600">Construction Cost Assistant</p>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="bg-white rounded-lg shadow-lg min-h-[600px] flex flex-col">
          {/* Messages */}
          <div className="flex-1 p-6 space-y-4 overflow-y-auto">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                    message.type === 'user'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  <p className="text-sm whitespace-pre-line">{message.content}</p>
                  <span className="text-xs opacity-70 mt-1 block">
                    {message.timestamp.toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Input Form */}
          {showForm && (
            <div className="p-6 border-t bg-gray-50">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Building className="w-5 h-5" />
                    Project Details
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        <Home className="w-4 h-4 inline mr-1" />
                        Area (sq ft)
                      </label>
                      <Input
                        type="number"
                        placeholder="e.g., 1200"
                        value={constructionParams.area || ''}
                        onChange={(e) => setConstructionParams(prev => ({
                          ...prev,
                          area: parseInt(e.target.value) || 0
                        }))}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">
                        <MapPin className="w-4 h-4 inline mr-1" />
                        Location
                      </label>
                      <Select
                        value={constructionParams.location}
                        onValueChange={(value) => setConstructionParams(prev => ({
                          ...prev,
                          location: value
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select location" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new-york">New York</SelectItem>
                          <SelectItem value="california">California</SelectItem>
                          <SelectItem value="texas">Texas</SelectItem>
                          <SelectItem value="florida">Florida</SelectItem>
                          <SelectItem value="illinois">Illinois</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">
                        <Building className="w-4 h-4 inline mr-1" />
                        Construction Type
                      </label>
                      <Select
                        value={constructionParams.constructionType}
                        onValueChange={(value) => setConstructionParams(prev => ({
                          ...prev,
                          constructionType: value
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="residential">Residential</SelectItem>
                          <SelectItem value="commercial">Commercial</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">
                        <Star className="w-4 h-4 inline mr-1" />
                        Material Quality
                      </label>
                      <Select
                        value={constructionParams.materialQuality}
                        onValueChange={(value) => setConstructionParams(prev => ({
                          ...prev,
                          materialQuality: value
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select quality" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="premium">Premium</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button 
                    onClick={handleFormSubmit}
                    className="w-full mt-6 bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600"
                    disabled={!constructionParams.area || !constructionParams.location || 
                             !constructionParams.constructionType || !constructionParams.materialQuality}
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Get Cost Estimate
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* New Estimate Button */}
          {!showForm && (
            <div className="p-4 border-t">
              <Button 
                onClick={resetChat}
                variant="outline"
                className="w-full"
              >
                <Calculator className="w-4 h-4 mr-2" />
                New Estimate
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Index;
